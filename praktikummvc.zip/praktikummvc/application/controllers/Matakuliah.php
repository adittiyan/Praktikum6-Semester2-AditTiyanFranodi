<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller{
    public function index() {
        $this->load->model('matakuliah_model', 'mtk1');
        $this->mtk1->nama="Pemograman Web 2";
        $this->mtk1->sks="3";
        $this->mtk1->kode="pw001";

        $this->load->model('matakuliah_model', 'mtk2');
        $this->mtk2->nama="Statistik dan Probabilitas";
        $this->mtk2->sks="2";
        $this->mtk2->kode="sp002";

        $this->load->model('matakuliah_model', 'mtk3');
        $this->mtk3->nama="UI UX";
        $this->mtk3->sks="3";
        $this->mtk3->kode="ux003";

        $list_mtk = [$this->mtk1, $this->mtk2, $this->mtk3];
        $data['list_mtk']=$list_mtk;

        $this->load->view('matakuliah/index',$data);
    }
}